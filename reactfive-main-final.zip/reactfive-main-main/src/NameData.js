/* eslint-disable import/no-anonymous-default-export */
export default [
  {
    nameOne: "Who We Are",
    nameTwo: "About Our Company",
    nameThree:
      "For over two decades, MCR Construction has been building and renovating properties in the Boston area. Owner Manuel Reynoso emigrated from Guatemala in 1986. He was trained as a union mason and carpenter, and was licensed as a general contractor in 1992.",
  },

  {
    number1: "1968",
    number2: "282",
    number3: "150",
    number4: "35",
  },

  {
    establishment: "Year of Establishment",
    projects: "Projects Completed",
    employees: "Professional Employess",
    partners: "Business Partners",
  },
];
